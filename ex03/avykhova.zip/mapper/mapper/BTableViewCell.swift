//
//  BTableViewCell.swift
//  mapper
//
//  Created by Anton VYKHOVANETS on 6/2/18.
//  Copyright © 2018 Vitas BRAZAS. All rights reserved.
//

import UIKit

class BTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
